//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WordAttach.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_WORDATTACH_DIALOG           102
#define IDR_WORDMENU                    129
#define IDC_EVENT                       1000
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_WORDATACHt                   32773
#define ID_WORDATACH                    32774
#define ID_WORDDETACH                   32775
#define ID_EVENTHOOK                    32776
#define ID_EVENTUNHOOK                  32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_ZOOM                         32780
#define ID_SCRZOOM                      32781
#define ID_SCRNORMAL                    32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
