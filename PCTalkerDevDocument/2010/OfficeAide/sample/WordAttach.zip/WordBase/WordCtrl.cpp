//--------------------------------------------------------------------
//			WORD�֐��N���X
//--------------------------------------------------------------------
#include "StdAfx.h"
#include "WordCtrl.h"
#include "WordObject.h"

//--------------------------------------------------
//			�A�v���P�[�V�����I�u�W�F�N�g(IDispatch)�̎擾 static
//
//	�߂�l : �A�v���P�[�V�����I�u�W�F�N�g
//--------------------------------------------------
LPDISPATCH CWordCtrl::GetWordAppDispatch()
{
	CLSID clsid;
	if (CLSIDFromProgID(OLESTR("Word.Application"), &clsid) != NOERROR)
		return	( NULL );

	LPUNKNOWN lpUnk = NULL;
	LPDISPATCH lpDispatch = NULL;

	if(GetActiveObject(clsid, NULL, &lpUnk) != NOERROR || !lpUnk )
		return	( NULL );

	HRESULT hr =lpUnk->QueryInterface(IID_IDispatch,(LPVOID*)&lpDispatch);
	lpUnk->Release();

	if (hr !=NOERROR)
		return	( NULL );

	return	( lpDispatch );
}
//--------------------------------------------------
//			�A�N�e�B�u�h�L�������g�̎擾
//
//	���@�� : aDocument	�A�N�e�B�u�h�L�������g
//	�߂�l : true=���� false=���s
//--------------------------------------------------
bool CWordCtrl::GetActiveDocument( CWordDocument* aDocument )
{
	bool bSuccess = false;
	CWordApplication app;
	LPDISPATCH		 pDisp;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( false );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_ActiveDocument()))
			return	( false );

		aDocument->AttachDispatch( pDisp );
		if( aDocument->m_lpDispatch )
			bSuccess = true;
	}
	catch( ... ){	bSuccess = false;	}

	return	( bSuccess );

}
//--------------------------------------------------
//			�h�L�������g���̎擾
//
//	���@�� : strDocname	�h�L�������g��
//	�߂�l : �擾����������
//--------------------------------------------------
int CWordCtrl::GetDocumentName( CString& strDocname )
{
	CWordDocument doc;
	if( GetActiveDocument( &doc ) == true )
		strDocname = doc.get_Name();	

	return	( strDocname.GetLength() );
}
//--------------------------------------------------
//			�y�[�W�ݒ蕶����̎擾
//
//	���@�� : strPageSetup	�y�[�W�ݒ蕶����
//	�߂�l : �擾����������
//--------------------------------------------------
int CWordCtrl::GetPageSetupString( CString& strPageSetup )
{
	CWordApplication  app;
	CWordDocument  doc;
	CWordPageSetup setup;
	CWordRange	   range;
	LPDISPATCH	   pDisp;
	CString		   strProp;

	if( GetActiveDocument( &doc ) == false )
		return	( 0 );

	try{
		if((pDisp = doc.get_PageSetup())){
			setup.AttachDispatch( pDisp );

			//	�p���T�C�Y�̎擾
			strPageSetup += _T("�T�C�Y ");
			GetPropertyString( WORD_PROPTYPE_PAPERSIZE,setup.get_PaperSize(),strProp );
			if( strProp.GetLength() )
				strPageSetup += strProp;
			else
				strPageSetup += _T("�s��");
			
			strProp.Empty();
			//	������C�A�E�g�̕���
			GetPropertyString( WORD_PROPTYPE_ORIENTATION,setup.get_Orientation(),strProp );
			if( strProp.GetLength() ){
				strPageSetup += _T(' ');
				strPageSetup += strProp;
			}
			//	�s���A�������̎擾
			strProp.Format( _T(" %ld�s %ld�� "),(long)setup.get_LinesPage(),(long)setup.get_CharsLine() );
			strPageSetup += _T(' ');
			strPageSetup += strProp;
		}
	}
	catch( ... ){	;	}

	//	������
	try{
		CComVariant var( 0,VT_I4 );
		if((pDisp = doc.Range( &var,&var ))){
			range.AttachDispatch( pDisp );
			GetPropertyString( WORD_PROPTYPE_TEXTORIENTATION,range.get_Orientation(),strProp );
			if( strProp.GetLength() ){
				strPageSetup += _T(' ');
				strPageSetup += strProp;
			}
		}
	}
	catch( ... ){	;	}

	//	�v�����^���̎擾
	try{
		if((pDisp = GetWordAppDispatch())){
			app.AttachDispatch( pDisp );
			strProp = app.get_ActivePrinter();
			if( strProp.GetLength() ){
				strPageSetup += _T(" �v�����^�� ");
				strPageSetup += strProp;
			}
		}
	}
	catch( ... ){	;	}

	return	( strPageSetup.GetLength() );
}
//--------------------------------------------------
//			��ʂ̐؂�ւ�(�ʏ�/�g��)
//
//	���@�� : aMode		��ʃ��[�h
//	�߂�l : true=����	false=���s
//--------------------------------------------------
bool CWordCtrl::SetScreenMode( WORD_SCREENMODE aMode )
{
	bool			  bSuccess = false;
	CWordApplication  app;
	CWordWindow		  window;
	CWordPane		  pane;
	CWordView		  view;
	CWordZoom		  zoom;
	CWordSelection	  selection;
	LPDISPATCH		  pDisp;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( false );

		app.AttachDispatch( pDisp );
		//	Options�C���^�[�t�F�C�X���擾
		if(!(pDisp = app.get_Options()))
			return	( false );

		//	Zoom�C���^�[�t�F�C�X���擾
		if(!(pDisp = app.get_ActiveWindow()))
			return	( false );
		window.AttachDispatch( pDisp );
		if(!(pDisp = window.get_ActivePane()))
			return	( false );
		pane.AttachDispatch( pDisp );
		if(!(pDisp = pane.get_View()))
			return	( false );
		view.AttachDispatch( pDisp );
		if(!(pDisp = view.get_Zoom()))
			return	( false );
		zoom.AttachDispatch( pDisp );

		VARIANT varNull;
		varNull.vt = VT_NULL;
		//	�g����
		if( aMode == WORD_SCREENMODE_MAGNIFICATION ){
			long nSelStart,dum;

			//	�I���J�n�ʒu���擾
			if(!(pDisp = app.get_Selection()))
				return	( false );
			selection.AttachDispatch( pDisp );
			nSelStart = selection.get_Start();	

			//	500%�̊g�嗦�ɐݒ肷��
			zoom.put_Percentage( WORD_SCREENMODE_MAGNIFICATION );
			//	�X�N���[���𐧌䂷��
			dum = selection.MoveLeft(&varNull,&varNull,&varNull );
			if( nSelStart != dum ){
				selection.MoveRight(&varNull,&varNull,&varNull );
			}
		}
		//	�ʏ���
		else{
			//	�{����100%�ɂ���
			zoom.put_Percentage( WORD_SCREENMODE_NORMAL );
		}
		bSuccess = true;
	}
	catch( ... ){	bSuccess = false;	}
	return	( bSuccess );

}
//--------------------------------------------------
//			��ʔ{���̎擾
//
//	�߂�l : ��ʔ{��
//--------------------------------------------------
long CWordCtrl::GetScreenPercentage()
{
	long			  nPercentage = WORD_SCREENMODE_NORMAL;
	CWordApplication  app;
	CWordWindow		  window;
	CWordPane		  pane;
	CWordView		  view;
	CWordZoom		  zoom;
	LPDISPATCH		  pDisp;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			goto	Exit;

		app.AttachDispatch( pDisp );

		//	Zoom�C���^�[�t�F�C�X���擾
		if(!(pDisp = app.get_ActiveWindow()))
			goto	Exit;
		window.AttachDispatch( pDisp );
		if(!(pDisp = window.get_ActivePane()))
			goto	Exit;
		pane.AttachDispatch( pDisp );
		if(!(pDisp = pane.get_View()))
			goto	Exit;
		view.AttachDispatch( pDisp );
		if(!(pDisp = view.get_Zoom()))
			goto	Exit;
		zoom.AttachDispatch( pDisp );
		nPercentage = zoom.get_Percentage();
	}
	catch( ... ){
		;
	}
Exit:
	return	( nPercentage );

}
//--------------------------------------------------
//			�I���e�L�X�g�̎擾(�J�[�\���ʒu)
//
//	���@�� : aString	�I���e�L�X�g
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetSelString( CString& aString )
{
	CWordApplication  app;
	CWordSelection	  selection;
	LPDISPATCH		  pDisp;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		//	�I���J�n�ʒu���擾
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		aString = selection.get_Text();
	}
	catch( ... ){ ; }

	return	( aString.GetLength() );
}
//--------------------------------------------------
//			�I���ʒu������̎擾(�J�[�\���ʒu)
//
//	���@�� : aString	�ʒu
//			 IsGetmm	�c�A����mm�ʒu���擾���邩�ǂ��� TRUE=���� FALSE=���Ȃ�
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetPosString( CString& aString,BOOL IsGetmm )
{
	CWordApplication  app;
	CWordSelection	  selection;
	LPDISPATCH		  pDisp;
	CString			  strProp;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );

		long  nPage=-1,nLine=-1,nColm=-1,nSection=1;

		CComVariant var;
		//	�y�[�W���擾
		var = selection.get_Information( wdActiveEndPageNumber );
		if( var.vt == VT_I4 ){
			nPage = var.lVal;
		}
		//	�s���擾
		var = selection.get_Information( wdFirstCharacterLineNumber );
		if( var.vt == VT_I4  )
			nLine = var.lVal;
		//	����擾
		var = selection.get_Information( wdFirstCharacterColumnNumber );
		if( var.vt == VT_I4  )
			nColm = var.lVal;
		//	�Z�N�V�����擾
		var = selection.get_Information( wdActiveEndSectionNumber );
		if( var.vt == VT_I4  )
			nSection = var.lVal;

		if( nLine == -1 ){
			if( nSection == 1 )
				aString.Format( _T("%ld�� %ld��"),nPage,nColm );
			else
				aString.Format( _T("%ld�� %ld�Z�N�V���� %ld��"),nPage,nSection,nColm );
		}
		else{
			if( nSection == 1 )
				aString.Format( _T("%ld�� %ld�s %ld��"),nPage,nLine,nColm );
			else
				aString.Format( _T("%ld�� %ld�Z�N�V���� %ld�s %ld��"),nPage,nLine,nSection,nColm );
		}
		//	�c�A���̗p���ʒu(mm)���擾����
		if( IsGetmm ){
			float Xmm=0.0,Ymm=0.0;

			//	�c�ʒu�擾
			var = selection.get_Information( wdVerticalPositionRelativeToPage );
			if( var.vt == VT_R4  )
				Ymm = var.fltVal;
			//	���ʒu�擾
			var = selection.get_Information( wdHorizontalPositionRelativeToPage );
			if( var.vt == VT_R4  )
				Xmm = var.fltVal;

			if( Ymm > 0.0 ){
				strProp.Format( _T("\xfffe�c %d�~��"),(int)((double)Ymm / 72.0 * 25.4 * 100.0)/100);
				aString += strProp;
			}
			if( Xmm > 0.0 ){
				if( Ymm > 0.0 )
					aString += _T(' ');
				else
					aString += _T('\xfffe');

				strProp.Format( _T("�� %d�~��"),(int)((double)Xmm / 72.0 * 25.4 * 100.0)/100);
				aString += strProp;
			}
		}
	}
	catch( ... ){ ; }

	return	( aString.GetLength() );
}
//--------------------------------------------------
//			����������̎擾(�J�[�\���ʒu)
//
//	���@�� : aString	����������
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetFormString( CString& aString )
{
	CString			  strProp;
	CWordApplication  app;
	CWordSelection	  selection;
	CWordParagraphs	  paragraphs;
	CWordParagraph	  paragraph;
	CWordRange		  range;
	CWordListParagraphs listParagraphs;
	LPDISPATCH		  pDisp;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		//	�I���ʒu���擾
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		if(!(pDisp = selection.get_Paragraphs()))
			return	( 0 );
		paragraphs.AttachDispatch( pDisp );
		if(!(pDisp = paragraphs.Item( 1 )))
			return	( 0 );
		paragraph.AttachDispatch( pDisp );
		//	�z�u���擾
		if(GetPropertyString( WORD_PROPTYPE_PARAGRAPHALIGNMENT,paragraph.get_Alignment() ,strProp ) == true )
			aString += strProp;

		//	�s�Ԏ擾	
		if(GetPropertyString( WORD_PROPTYPE_LINESPACING,paragraph.get_LineSpacingRule() ,strProp ) == true ){
			if(aString.GetLength()) aString += _T(' ');
			aString += _T("�s��");
			aString += strProp;
		}

		//	�C���f���g�̎擾
		float nFirstIndent,nLeftIndent,nRightIndent;
		nFirstIndent = paragraph.get_FirstLineIndent();
		nLeftIndent  = paragraph.get_LeftIndent();
		nRightIndent = paragraph.get_RightIndent();
		if( nFirstIndent && nFirstIndent+nLeftIndent  ){
			strProp.Format( _T(" �P�s�ڂ̃C���f���g %.f�|�C���g"),nFirstIndent+nLeftIndent );
			aString += strProp;
		}
		if( nLeftIndent ){
			if( nFirstIndent < 0 )
				strProp.Format( _T(" �Ԃ炳���C���f���g %.f�|�C���g"),nLeftIndent );
			else
				strProp.Format( _T(" ���C���f���g %.f�|�C���g"),nLeftIndent );
			aString += strProp;
		}
		if( nRightIndent ){
			strProp.Format( _T(" �E�C���f���g %.f�|�C���g"),nLeftIndent );
			aString += strProp;
		}
		if((pDisp = paragraph.get_Range())){
			range.AttachDispatch( pDisp );
			listParagraphs.AttachDispatch( range.get_ListParagraphs() );
			if( listParagraphs.get_Count() > 0 ){
				CWordListFormat lstForm;

				if((pDisp = range.get_ListFormat())){
					lstForm.AttachDispatch( pDisp );
					strProp = lstForm.get_ListString();
					if( strProp.GetLength() ){
						aString += _T(" �ӏ����� ");
						aString += strProp;
					}
				}
			}
		}
	}
	catch( ... ){ ; }

	return	( aString.GetLength() );
}
//--------------------------------------------------
//			�I�u�W�F�N�g��񕶎���̎擾(�J�[�\���ʒu)
//
//	���@�� : aString	�I�u�W�F�N�g��񕶎���
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetShapeString( CString& aString )
{
	CWordApplication  app;
	CWordShapeRange	  shape;
	CWordSelection	  selection;
	LPDISPATCH		  pDisp;
	CString			  strProp;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		if(!(pDisp = selection.get_ShapeRange()))
			return	( 0 );
		shape.AttachDispatch( pDisp );
		if( shape.get_Count() ){
			strProp = shape.get_Name();
			aString = _T("�I�u�W�F�N�g��\xfffe") + strProp;
		}

	}
	catch( ... ){ ;	}

	if( strProp.IsEmpty() )
		aString = _T("�}�`�ȊO�̃I�u�W�F�N�g");

	return	( aString.GetLength() );
}
//--------------------------------------------------
//			�I���ʒu�̃Z���ʒu���擾
//
//	���@�� : aLine	�s�ʒu
//			 aColm  ��ʒu
//	�߂�l : true=�Z�� false=�Ⴄ
//--------------------------------------------------
bool CWordCtrl::GetCellPosition( long* aLine, long* aColm )
{
	CWordApplication  app;
	CWordSelection	  selection;
	LPDISPATCH		  pDisp;
	long nLine=-1,nColm=-1;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		CComVariant var;
		var = selection.get_Information( wdStartOfRangeColumnNumber );
		if( var.vt == VT_I4 )
			nColm = var.lVal;

		var = selection.get_Information( wdStartOfRangeRowNumber );
		if( var.vt == VT_I4 )
			nLine = var.lVal;
	}
	catch( ... ){ ;	}

	if( aLine )
		*aLine = nLine;
	if( aColm )
		*aColm = nColm;

	if( nLine <= 0 || nColm <= 0 )
		return	( false );

	return	( true );
}
//--------------------------------------------------
//			�\��񕶎���̎擾
//
//	���@�� : CString& aString	�\��񕶎���
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetTableString( CString& aString )
{
	CWordApplication  app;
	CWordSelection	  selection;
	CWordCells		  cells;
	CWordCell		  cell;
	CWordBorders	  borders;
	CWordBorder		  border;
	LPDISPATCH		  pDisp;
	CString			  strProp;
	long nLine,nColm;

	if(!GetCellPosition( &nLine,&nColm )){
		aString = _T("�r�� �Ȃ�");
		goto	Exit;
	}
	aString.Format( _T("�Z�� %ld�s%ld��	"),nLine,nColm );

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		if(!(pDisp = selection.get_Cells()))
			return	( 0 );
		cells.AttachDispatch(pDisp);
		if(!(pDisp = cells.get_Borders()))
			return	( 0 );
		borders.AttachDispatch( pDisp );
		//------------------
		aString += _T("�r�� ���� ");
		if(GetTBLineString( wdBorderTop,&borders,strProp ) > 0)
			aString += strProp;
		else
			aString += _T("�Ȃ�");
		//------------------
		aString += _T(" �r�� ���� ");
		if(GetTBLineString( wdBorderBottom,&borders,strProp ) > 0)
			aString += strProp;
		else
			aString += _T("�Ȃ�");
		//------------------
		aString += _T(" �r�� �Ђ��� ");
		if(GetTBLineString( wdBorderLeft,&borders,strProp ) > 0)
			aString += strProp;
		else
			aString += _T("�Ȃ�");
		//------------------
		aString += _T(" �r�� �݂� ");
		if(GetTBLineString( wdBorderRight,&borders,strProp ) > 0)
			aString += strProp;
		else
			aString += _T("�Ȃ�");

	}
	catch( ... ){	;	}

Exit:
	return	( aString.GetLength() );
}
//--------------------------------------------------
//			�\����񕶎���̎擾
//
//	���@�� : nLine		�r���̎��(WdBorderType ��Ƃ�...)
//			 aBoarders	�r���I�u�W�F�N�g
//			 aString	����񕶎���
//
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetTBLineString( long nLine,CWordBorders* aBoarders,CString& aString )
{
	CWordBorder		  border;
	LPDISPATCH		  pDisp;
	CString			  strProp;

	aString.Empty();
	try{
		if(!(pDisp = aBoarders->Item( nLine )))
			goto	Exit;

		border.AttachDispatch( pDisp );
		strProp.Empty();
		if(!border.get_Visible())
			goto	Exit;

		//	����
		GetPropertyString( WORD_PROPTYPE_LINESTYLE,border.get_LineStyle(),strProp );
		aString += strProp;

		//	����
		GetPropertyString( WORD_PROPTYPE_LINEWIDTH,border.get_LineWidth(),strProp );
		if( strProp.GetLength() ){
			if( aString.GetLength() )
				aString += _T(' ');
			aString += strProp;
		}
		//	���F
		GetPropertyString( WORD_PROPTYPE_COLOR,border.get_ColorIndex(),strProp );
		if( strProp.GetLength() ){
			if( aString.GetLength() )
				aString += _T(' ');
			aString += strProp;
		}
	}
	catch( ... ){	;	}
Exit:
	return	( aString.GetLength() );

}
//--------------------------------------------------
//			������񕶎���̎擾
//
//	���@�� : CString& aString	������񕶎���
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetCharString( CString& aString )
{
	CWordApplication  app;
	CWordSelection	  selection;
	CWordStyle		  style;
	CWordFont		  font;
	CWordShading	  shading;
	LPDISPATCH		  pDisp;
	CString			  strChar;
	wchar_t			  wChar;
	CComVariant		  var;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		strChar = selection.get_Text();
		if( !strChar.GetLength() ) 
			goto	Exit;

		wChar = strChar.GetAt( 0 );
		if( wChar < 256 )
			aString = _T("���p");
		else
			aString = _T("�S�p");

		strChar.Empty();
		if( wChar >= L'��' && wChar <= L'��' )
			strChar = _T("�Ђ炪��");
		else if((wChar >= L'�' && wChar <= L'�' ) || (wChar >= L'�@' && wChar <= L'��' ))
			strChar = _T("��������");
		else if((wChar >= L'a' && wChar <= L'z' ) || (wChar >= L'��' && wChar <= L'��' ))
			strChar = _T("�p�� ������");
		else if((wChar >= L'A' && wChar <= L'Z' ) || (wChar >= L'�`' && wChar <= L'�y' ))
			strChar = _T("�p�� �啶��");

		if(strChar.GetLength()){
			aString += _T(' ');
			aString += strChar;
		}
		var = selection.get_Style();
		if( var.vt == VT_DISPATCH ){
			style.AttachDispatch( var.pdispVal );
			strChar = style.get_NameLocal();
			if( _tcscmp( strChar,_T("�W��"))){
				aString += _T(' ');
				aString += strChar;
				aString += _T("�̃X�^�C��");
			}
		}
		//	�t�H���g���̎擾
		if(!(pDisp = selection.get_Font()))
			return	( 0 );

		font.AttachDispatch( pDisp );
		aString += _T(' ');
		aString += font.get_Name();

		strChar.Format( _T(" %.f�|�C���g"),font.get_Size() );
		aString += strChar;

		if(font.get_Bold() == VARIANT_TRUE )
			aString += _T(" ����");

		if(font.get_Underline() == VARIANT_TRUE )
			aString += _T(" �A���_�[���C��");

		if(font.get_Italic() == VARIANT_TRUE )
			aString += _T(" �Α�");

		if(GetPropertyString( WORD_PROPTYPE_COLOR,font.get_ColorIndex(),strChar ) == true){
			aString += _T(' ');
			aString += strChar;
		}

		if(font.get_DoubleStrikeThrough() == VARIANT_TRUE )
			aString += _T(" ��d��������");
		if(font.get_Emboss() == VARIANT_TRUE )
			aString += _T(" ��������");
		if(font.get_EmphasisMark() == VARIANT_TRUE )
			aString += _T(" �T�_");
		if(font.get_Engrave() == VARIANT_TRUE )
			aString += _T(" ������");
		if(font.get_Hidden() == VARIANT_TRUE )
			aString += _T(" �B������");
		if(font.get_Outline() == VARIANT_TRUE )
			aString += _T(" ������");
		if(font.get_Shadow() == VARIANT_TRUE )
			aString += _T(" �e�t��");
		if(font.get_StrikeThrough() == VARIANT_TRUE )
			aString += _T(" �������");
		if(font.get_Subscript() == VARIANT_TRUE )
			aString += _T(" ���t������");
		if(font.get_Superscript() == VARIANT_TRUE )
			aString += _T(" ��t������");
		if(font.get_Scaling() != 100 ){
			strChar.Format( _T(" �����{��%ld"),font.get_Scaling() );
			aString += strChar;
		}

		if((pDisp = font.get_Shading())){
			shading.AttachDispatch( pDisp );
			if(GetPropertyString( WORD_PROPTYPE_TEXTURE,shading.get_Texture(),strChar ) == true){
				aString += _T(" �Ԋ|���X�^�C�� ");
				aString += strChar;
			}
		}
	}
	catch( ... ){ ;	}
Exit:
	return	( aString.GetLength() );
}
//--------------------------------------------------
//			�s������̎擾
//
//	���@�� : CString& aString	������񕶎���
//	�߂�l : ������
//--------------------------------------------------
int CWordCtrl::GetLineString( CString& aString )
{
	CWordApplication  app;
	CWordSelection	  selection;
	CWordParagraphs	  paragraphs;
	CWordParagraph	  paragraph;
	CWordRange		  range,rangeLine;
	CWordBookmarks	  bookmarks;
	CWordBookmark	  bookmark;
	LPDISPATCH		  pDisp;
	CComVariant		  var;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		if(!(pDisp = selection.get_Paragraphs()))
			return	( 0 );
		paragraphs.AttachDispatch( pDisp );
		if(!(pDisp = paragraphs.Item( 1 )))
			return	( 0 );
		paragraph.AttachDispatch( pDisp );
		if(!(pDisp = paragraph.get_Range()))
			return	( 0 );
		range.AttachDispatch( pDisp );
		if(!(pDisp = range.get_Bookmarks()))
			return	( 0 );
		bookmarks.AttachDispatch( pDisp );
		var = L"\\Line";
		if(!(pDisp = bookmarks.Item( &var )))
			return	( 0 );

		bookmark.AttachDispatch( pDisp );
		if(!(pDisp = bookmark.get_Range()))
			return	( 0 );
		rangeLine.AttachDispatch( pDisp );
		aString = rangeLine.get_Text();
	}
	catch( ... ){ ;	}

	return	( aString.GetLength() );
}
//--------------------------------------------------
//			�I���ʒu�̎擾(�J�[�\���ʒu)
//
//	���@�� : long* aSelStart	�͈͊J�n�ʒu
//			 long* aSelEnd		�͈͏I���ʒu
//	�߂�l : true=���� false=���s
//--------------------------------------------------
bool CWordCtrl::GetSelIndex( long* aSelStart,long* aSelEnd )
{
	CWordApplication  app;
	CWordSelection	  selection;
	LPDISPATCH		  pDisp;
	bool			  bSuccess = false;
	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( false );

		app.AttachDispatch( pDisp );
		//	�I���ʒu���擾
		if(!(pDisp = app.get_Selection()))
			return	( false );
		selection.AttachDispatch( pDisp );
		if( aSelStart )
			*aSelStart = selection.get_Start();

		if( aSelEnd )
			*aSelEnd = selection.get_End();

		bSuccess = true;
	}
	catch( ... ){ ; }

	return	( bSuccess );
}
//--------------------------------------------------
//			�I���ʒu�̃J�����ʒu���擾
//
//	���@�� : aColm  �J�����ʒu
//
//	�߂�l : true=���� false=���s
//--------------------------------------------------
bool CWordCtrl::GetColmPosition( long* aColm )
{
	CWordApplication  app;
	CWordSelection	  selection;
	LPDISPATCH		  pDisp;
	bool			  bSuccess = false;

	try{
		if(!(pDisp = GetWordAppDispatch()))
			return	( 0 );

		app.AttachDispatch( pDisp );
		if(!(pDisp = app.get_Selection()))
			return	( 0 );
		selection.AttachDispatch( pDisp );
		CComVariant var;
		var = selection.get_Information( wdFirstCharacterColumnNumber );
		if( var.vt == VT_I4 ){
			*aColm   = var.lVal;
			bSuccess = true;
		}
	}
	catch( ... ){ ;	}

	return	( bSuccess );
}
