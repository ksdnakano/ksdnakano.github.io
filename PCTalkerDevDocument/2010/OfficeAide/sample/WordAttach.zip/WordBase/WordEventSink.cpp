//--------------------------------------------------------
//			WORD�C�x���g�����N���X
//--------------------------------------------------------
#include "StdAfx.h"
#include "WordEventSink.h"
#include "WordCtrl.h"

//#include "agsapi.h"

CWordEventSink* CWordEventSink::mpThis = NULL;

//-------------------------------------------------------------
//			�C�x���g�Ƀt�b�N	static 
//-------------------------------------------------------------
bool CWordEventSink::HookEvent( HWND aWnd )
{
	bool bSuccess = false;

	if( mpThis )
		return	( TRUE );

	if((mpThis = new CWordEventSink )){
		mpThis->mhWnd = aWnd;
		if( mpThis->mpDispApp )
			bSuccess = true;
		else
			UnhookEvent();
	}
	return	( bSuccess );
}
//-------------------------------------------------------------
//			�t�b�N����			static 
//-------------------------------------------------------------
void CWordEventSink::UnhookEvent()
{
	if( mpThis ){
		mpThis->mhWnd = NULL;
		LPDISPATCH pDisp = mpThis->mpDispApp;
		if( pDisp )
			mpThis->Unadvise();

		mpThis->Release();

		if(  pDisp )
			pDisp->Release();

		mpThis = NULL;
	}
}
//-------------------------------------------------------------
//			�t�b�N���Ă��邩�ǂ���	static 
//-------------------------------------------------------------
bool CWordEventSink::IshookEvent()
{
	return	( mpThis ? true : false );
}

//-------------------------------------------------------------
//			�\�z
//-------------------------------------------------------------
CWordEventSink::CWordEventSink(void)
{
	//	�C�x���g�o�^
	if((mpDispApp = CWordCtrl::GetWordAppDispatch())){
		if(Advise( mpDispApp ) != S_OK ){
			mpDispApp->Release();
			mpDispApp = NULL;
		}
	}
}
//-------------------------------------------------------------
//			����
//-------------------------------------------------------------
CWordEventSink::~CWordEventSink(void)
{
	//	�C�x���g�o�^����
/*	if( mpDispApp ){
		Unadvise();
		mpDispApp->Release();
		mpDispApp = NULL;
	}*/
}
//-------------------------------------------------------------
//			WORD�̏I��
//-------------------------------------------------------------
void CWordEventSink::OnQuit()
{
	if( ::IsWindow( mhWnd ))
		::PostMessage( mhWnd,WM_WORD_QUIT,0,0 );

	UnhookEvent();
//	CAgsApi api;
//	api.PReadW( L"���[�h �I���",0,TRUE,0 );
}
//-------------------------------------------------------------
//			�ҏW�����̕ύX
//-------------------------------------------------------------
void CWordEventSink::OnDocumentChange()
{
	if( ::IsWindow( mhWnd ))
		::SendMessage( mhWnd,WM_WORD_DOCCHANGE,0,0 );

//	CStringW strDocName;
//	if(CWordCtrl::GetDocumentName( strDocName )){
//		strDocName += _T(" �A�N�e�B�u");
//		CAgsApi api;
//		api.PReadW( strDocName,0,TRUE,0 );
//	}
}
//-------------------------------------------------------------
//			�ҏW�����̃I�[�v��
//-------------------------------------------------------------
void CWordEventSink::OnDocumentOpen( CWordDocument& pDoc )
{
	if( ::IsWindow( mhWnd ))
		::SendMessage( mhWnd,WM_WORD_DOCOPEN,0,0 );
//	CAgsApi api;
//	api.PReadW( L"���[�h �I���",0,TRUE,0 );
}
//-------------------------------------------------------------
//			�V�K����
//-------------------------------------------------------------
void CWordEventSink::OnNewDocument( CWordDocument& pDoc )
{
	if( ::IsWindow( mhWnd ))
		::SendMessage( mhWnd,WM_WORD_DOCNEW,0,0 );
//	CAgsApi api;
//	api.PReadW( L"�V�K",0,TRUE,0 );
}
//-------------------------------------------------------------
//			�E�C���h�E�A�N�e�B�u
//-------------------------------------------------------------
void CWordEventSink::OnWindowActivate( CWordDocument& aDocument,CWordWindow& aWindow )
{
	if( ::IsWindow( mhWnd ))
		::SendMessage( mhWnd,WM_WORD_WINACTIVATE,0,0 );
//	CAgsApi agsapi;
//	agsapi.PReadW( L"WORD-WindowActivate",4,TRUE,0 );
}
//-------------------------------------------------------------
//			�I���̕ύX
//-------------------------------------------------------------
void CWordEventSink::OnWindowSelectionChange( CWordSelection& aSelection )
{
	if( ::IsWindow( mhWnd ))
		::SendMessage( mhWnd,WM_WORD_SELCHANGE,0,0 );
}
