// WordEvents.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "WordEvents.h"
#include "WordCtrl.h"

// CWordEvents

/******************************************************************************
*   Invoke -- Takes a dispid and uses it to call another of the methods of this 
*   class. Returns S_OK if the call was successful.
******************************************************************************/ 
STDMETHODIMP CWordEvents::Invoke(DISPID dispIdMember, REFIID riid, LCID lcid,
                                       WORD wFlags, DISPPARAMS* pDispParams,
                                       VARIANT* pVarResult,
                                       EXCEPINFO* pExcepInfo,
                                       UINT* puArgErr)
{
   if ((riid != IID_NULL))
      return E_INVALIDARG;

   HRESULT hr = S_OK;

	switch(dispIdMember){
	case DISPID_WORDAPP_STARTUP:
		OutputDebugString(_T("Startup\n"));
		OnStartUp();
		break;
	case DISPID_WORDAPP_QUIT:  //Quit();
		OutputDebugString( _T("Quit\n"));
		OnQuit();
		break;
	case DISPID_WORDAPP_DOCUMENTCHANGE:  //DocumentChange();
		OutputDebugString( _T("DocumentChange\n"));
		OnDocumentChange();
		break;
	case DISPID_WORDAPP_DOCUMENTOPEN:  //DocumentOpen([in] Document* Doc);
		OutputDebugString( _T("DocumentOpen\n"));
		if( pDispParams->cArgs >= 1 ){
			CWordDocument wDoc;
			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wDoc.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wDoc.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if( wDoc.m_lpDispatch ){
				try{
					OnDocumentOpen( wDoc );
				}
				catch(...){
				}
				wDoc.DetachDispatch();
			}
		}
		break;
	case DISPID_WORDAPP_DOCUMENTBEFORECLOSE:  // DocumentBeforeClose([in] Document* Doc, [in] VARIANT_BOOL* Cancel);
		OutputDebugString( _T("DocumentBeforeClose\n"));
		if( pDispParams->cArgs >= 2 ){
			CWordDocument wDoc;
			VARIANT_BOOL  cancel  = VARIANT_FALSE;
			VARIANT_BOOL* pCancel = &cancel;

			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wDoc.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wDoc.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if(pDispParams->rgvarg[1].vt & VT_BYREF)
				pCancel = pDispParams->rgvarg[1].pboolVal;
			else
				cancel = pDispParams->rgvarg[1].boolVal;

			if( wDoc.m_lpDispatch ){
				BOOL bCancel = FALSE;
				try{
					OnDocumentBeforeClose( wDoc,&bCancel );
					if( bCancel && pDispParams->rgvarg[1].vt & VT_BYREF)
						*(pDispParams->rgvarg[1].pboolVal) = VARIANT_TRUE;
				}
				catch(...){
				}
				wDoc.DetachDispatch();
			}
		}
		break;
	case DISPID_WORDAPP_DOCUMENTBEFOREPRINT:  // DocumentBeforePrint([in] Document* Doc, [in] VARIANT_BOOL* Cancel);
		OutputDebugString( _T("DocumentBeforePrint\n"));
		if( pDispParams->cArgs >= 2 ){
			CWordDocument wDoc;
			VARIANT_BOOL  cancel  = VARIANT_FALSE;
			VARIANT_BOOL* pCancel = &cancel;

			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wDoc.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wDoc.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if(pDispParams->rgvarg[1].vt & VT_BYREF)
				pCancel = pDispParams->rgvarg[1].pboolVal;
			else
				cancel = pDispParams->rgvarg[1].boolVal;

			if( wDoc.m_lpDispatch ){
				BOOL bCancel = FALSE;
				try{
					OnDocumentBeforePrint( wDoc,&bCancel );
					if( bCancel && pDispParams->rgvarg[1].vt & VT_BYREF)
						*(pDispParams->rgvarg[1].pboolVal) = VARIANT_TRUE;
				}
				catch(...){
				}
				wDoc.DetachDispatch();
			}
		}
		break;
	case DISPID_WORDAPP_DOCUMENTBEFORESAVE:  // DocumentBeforeSave([in] Document* Doc, [in] VARIANT_BOOL* SaveAsUI, [in] VARIANT_BOOL* Cancel);
		OutputDebugString( _T("DocumentBeforeSave\n"));
		if( pDispParams->cArgs >= 3 ){
			CWordDocument wDoc;
			VARIANT_BOOL  UIcancel   = VARIANT_FALSE;
			VARIANT_BOOL* pUICancel = &UIcancel;

			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wDoc.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wDoc.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if(pDispParams->rgvarg[1].vt & VT_BYREF)
				pUICancel = pDispParams->rgvarg[1].pboolVal;
			else
				UIcancel = pDispParams->rgvarg[1].boolVal;

			if( wDoc.m_lpDispatch ){
				BOOL bCancel = FALSE,bUICancel = *pUICancel;
				try{
					OnDocumentBeforeSave( wDoc,&bUICancel,&bCancel );
					if( bUICancel )
						*pUICancel = VARIANT_TRUE;
					else
						*pUICancel = VARIANT_FALSE;

					if( bCancel && pDispParams->rgvarg[2].vt & VT_BYREF)
						*(pDispParams->rgvarg[1].pboolVal) = VARIANT_TRUE;
				}
				catch(...){
				}
				wDoc.DetachDispatch();
			}
		}
		break;
	case DISPID_WORDAPP_NEWDOCUMENT:  // NewDocument([in] Document* Doc);
		OutputDebugString( _T("New Document\n"));
		if( pDispParams->cArgs >= 1 ){
			CWordDocument wDoc;
			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wDoc.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wDoc.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if( wDoc.m_lpDispatch ){
				try{
					OnNewDocument( wDoc );
				}
				catch(...){
				}
				wDoc.DetachDispatch();
			}
		}
		break;
	case DISPID_WORDAPP_WINDOWACTIVATE:  // WindowActivate([in] Document* Doc, [in] Window* Wn);
		OutputDebugString( _T("WindowActivate\n"));
		if( pDispParams->cArgs >= 2 ){
			CWordDocument wDoc;
			CWordWindow	  wWindow;

			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wDoc.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wDoc.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if(pDispParams->rgvarg[1].vt & VT_BYREF)
				wWindow.AttachDispatch( *(pDispParams->rgvarg[1].ppdispVal) );
			else
				wWindow.AttachDispatch( pDispParams->rgvarg[1].pdispVal );

			if( wDoc.m_lpDispatch && wWindow.m_lpDispatch ){
				try{
					OnWindowActivate( wDoc,wWindow );
				}
				catch(...){
				}
				wWindow.DetachDispatch();
				wDoc.DetachDispatch();
			}
		}
		break;
		// Next 3 illustrate passing parameters to real event handler functions.
	case DISPID_WORDAPP_WINDOWDEACTIVATE:  // WindowDeactivate([in] Document* Doc, [in] Window* Wn);
		OutputDebugString( _T("WindowDeactivate\n"));
		if( pDispParams->cArgs >= 2 ){
			CWordDocument wDoc;
			CWordWindow	  wWindow;

			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wDoc.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wDoc.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if(pDispParams->rgvarg[1].vt & VT_BYREF)
				wWindow.AttachDispatch( *(pDispParams->rgvarg[1].ppdispVal) );
			else
				wWindow.AttachDispatch( pDispParams->rgvarg[1].pdispVal );

			if( wDoc.m_lpDispatch && wWindow.m_lpDispatch ){
				try{
					OnWindowDeactivate( wDoc,wWindow );
				}
				catch(...){
				}
				wWindow.DetachDispatch();
				wDoc.DetachDispatch();
			}
		}

		break;
	//	�I���̕ύX
	case DISPID_WORDAPP_WINDOWSELECTIONCHANGE:  // WindowSelectionChange([in] Selection* Sel);
		OutputDebugString( _T("WindowSelectionChange\n"));
		if( pDispParams->cArgs >= 1 ){
			CWordSelection wSelection;
			if(pDispParams->rgvarg[0].vt & VT_BYREF)
				wSelection.AttachDispatch( *(pDispParams->rgvarg[0].ppdispVal) );
			else
				wSelection.AttachDispatch( pDispParams->rgvarg[0].pdispVal );

			if( wSelection.m_lpDispatch ){
				try{
					OnWindowSelectionChange( wSelection );
				}
				catch(...){
				}
				wSelection.DetachDispatch();
			}
		}
		break;
	case DISPID_WORDAPP_WINDOWBEFOREDOUBLECLICK:  // WindowBeforeDoubleClick([in] Selection*  Sel, [in] VARIANT_BOOL* Cancel);
		OutputDebugString( _T("WindowBeforeDoubleClick\n"));
		break;
	}
	return hr;
}
//---------------------------------------------------------------
//		WORD�v���Z�X�̊J�n
//---------------------------------------------------------------
void CWordEvents::OnStartUp()
{
	;
}
//---------------------------------------------------------------
//		���ׂĂ�WORD�v���Z�X�̏I��
//---------------------------------------------------------------
void CWordEvents::OnQuit()
{
	;
}
//---------------------------------------------------------------
//		�A�N�e�B�u�ȃh�L�������g�̕ύX
//---------------------------------------------------------------
void CWordEvents::OnDocumentChange()
{
	;
}
//---------------------------------------------------------------
//		�V�K
//---------------------------------------------------------------
void CWordEvents::OnNewDocument( CWordDocument& pDoc )
{
	;
}
//---------------------------------------------------------------
//		�h�L�������g�̃I�[�v��
//---------------------------------------------------------------
void CWordEvents::OnDocumentOpen( CWordDocument& pDoc )
{
	;
}
//---------------------------------------------------------------
//		�h�L�������g��������
//
//	���@�� :	pDoc		�h�L�������g�I�u�W�F�N�g
//				aIsCancel	����̂��L�����Z������ꍇ��TRUE���Z�b�g����
//---------------------------------------------------------------
void CWordEvents::OnDocumentBeforeClose( CWordDocument& pDoc,BOOL* aIsCancel )
{
	;
}
//---------------------------------------------------------------
//		�h�L�������g���ۑ������
//
//	���@�� :	pDoc		�h�L�������g�I�u�W�F�N�g
//				aIsUICancel TRUE="���O��t���ĕۑ�"�_�C�A���O�\��
//				aIsCancel	TRUE=�ۑ����~
//---------------------------------------------------------------
void CWordEvents::OnDocumentBeforeSave( CWordDocument& pDoc,BOOL* aIsUICancel,BOOL* aIsCancel )
{
	;
}
//---------------------------------------------------------------
//		�h�L�������g����������
//
//	���@�� :	pDoc		�h�L�������g�I�u�W�F�N�g
//				aIsCancel	������L�����Z������ꍇ��TRUE���Z�b�g����
//---------------------------------------------------------------
void CWordEvents::OnDocumentBeforePrint( CWordDocument& pDoc,BOOL* aIsCancel )
{
	;
}
//---------------------------------------------------------------
//		�E�C���h�E�A�N�e�B�u
//
//	���@�� :	aDocument	�h�L�������g�I�u�W�F�N�g
//				aWindow		�E�C���h�E�I�u�W�F�N�g
//---------------------------------------------------------------
void CWordEvents::OnWindowActivate( CWordDocument& aDocument,CWordWindow& aWindow )
{
	;
}
//---------------------------------------------------------------
//		�E�C���h�E��A�N�e�B�u
//
//	���@�� :	aDocument	�h�L�������g�I�u�W�F�N�g
//				aWindow		�E�C���h�E�I�u�W�F�N�g
//---------------------------------------------------------------
void CWordEvents::OnWindowDeactivate( CWordDocument& aDocument,CWordWindow& aWindow )
{
	;
}
//---------------------------------------------------------------
//		�I���̕ύX
//
//	���@�� :	aSelection	�I���I�u�W�F�N�g
//---------------------------------------------------------------
void CWordEvents::OnWindowSelectionChange( CWordSelection& aSelection )
{
	;
}
