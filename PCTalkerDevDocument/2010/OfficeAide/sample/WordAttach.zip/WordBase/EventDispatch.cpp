#include "StdAfx.h"
#include "EventDispatch.h"

CEventDispatch::CEventDispatch( GUID aGuidEvents )
{
	m_refCount    = 1;
	m_guidEvents  = aGuidEvents;
	mConnectPoint = NULL;
	mCookie       = 0;
}

CEventDispatch::~CEventDispatch(void)
{
}
STDMETHODIMP CEventDispatch::QueryInterface(REFIID riid, void ** ppvObj)
{
   if (riid == IID_IUnknown){
      *ppvObj = static_cast<IUnknown*>(this);
   }

   else if (riid == IID_IDispatch){
      *ppvObj = static_cast<IDispatch*>(this);
   }

   else if (riid == m_guidEvents ){
      *ppvObj = static_cast<IDispatch*>(this);
   }

   else{
      *ppvObj = NULL;
      return E_NOINTERFACE;
   }

   static_cast<IUnknown*>(*ppvObj)->AddRef();
   return S_OK;
}
/******************************************************************************
*   GetTypeInfoCount -- This function determines if the class supports type 
*   information interfaces or not. It places 1 in iTInfo if the class supports
*   type information and 0 if it does not.
******************************************************************************/ 
STDMETHODIMP CEventDispatch::GetTypeInfoCount(UINT *iTInfo)
{
   *iTInfo = 0;
   return S_OK;
}

/******************************************************************************
*   GetTypeInfo -- Returns the type information for the class. For classes 
*   that do not support type information, this function returns E_NOTIMPL;
******************************************************************************/ 
STDMETHODIMP CEventDispatch::GetTypeInfo(UINT iTInfo, LCID lcid, 
                                            ITypeInfo **ppTInfo)
{
   return E_NOTIMPL;
}

/******************************************************************************
*   GetIDsOfNames -- Takes an array of strings and returns an array of DISPIDs
*   that correspond to the methods or properties indicated. If the name is not 
*   recognized, it returns DISP_E_UNKNOWNNAME.
******************************************************************************/ 
STDMETHODIMP CEventDispatch::GetIDsOfNames(REFIID riid,  
                                              OLECHAR **rgszNames, 
                                              UINT cNames,  LCID lcid,
                                              DISPID *rgDispId)
{
   return E_NOTIMPL;
}
/******************************************************************************
*  AddRef() -- In order to allow an object to delete itself when 
*  it is no longer needed, it is necessary to maintain a count of all 
*  references to this object.  When a new reference is created, this function 
*  increments the count.
******************************************************************************/ 
STDMETHODIMP_(ULONG) CEventDispatch::AddRef()
{
   return ++m_refCount;
}

/******************************************************************************
*  Release() -- When a reference to this object is removed, this 
*  function decrements the reference count.  If the reference count is 0, 
*  this function deletes this object and returns 0.
******************************************************************************/ 
STDMETHODIMP_(ULONG) CEventDispatch::Release()
{
   m_refCount--;
   if (m_refCount == 0)
   {
      delete this;
      return 0;
   }
   return m_refCount;
}

/******************************************************************************
*   Invoke -- Takes a dispid and uses it to call another of the methods of this 
*   class. Returns S_OK if the call was successful.
******************************************************************************/ 
STDMETHODIMP CEventDispatch::Invoke(DISPID dispIdMember, REFIID riid, LCID lcid,
                                       WORD wFlags, DISPPARAMS* pDispParams,
                                       VARIANT* pVarResult,
                                       EXCEPINFO* pExcepInfo,
                                       UINT* puArgErr)
{
   return S_FALSE;
}
//-----------------------------------------------------------------------------
//		�C�x���g�ɐڑ�
//-----------------------------------------------------------------------------
HRESULT CEventDispatch::Advise( LPDISPATCH aDisp )
{
	IConnectionPointContainer *pConnPtContainer;
	if(!SUCCEEDED(aDisp->QueryInterface( IID_IConnectionPointContainer,
						(void **)&pConnPtContainer )))
		return ( S_FALSE );

	HRESULT hr = S_FALSE;
	if(SUCCEEDED(pConnPtContainer->FindConnectionPoint(m_guidEvents,
		&mConnectPoint ))){
		AddRef();
		hr = mConnectPoint->Advise( this,&mCookie );
	}
	pConnPtContainer->Release();
	return	( hr );	
}
//-----------------------------------------------------------------------------
//		�C�x���g����؂藣��
//-----------------------------------------------------------------------------
void CEventDispatch::Unadvise()
{
	if( mConnectPoint ){
		mConnectPoint->Unadvise( mCookie );
		mCookie = 0;
		mConnectPoint->Release();
		mConnectPoint = NULL;
	}
	Release();
}
