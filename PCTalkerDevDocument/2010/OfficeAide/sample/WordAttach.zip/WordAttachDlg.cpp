
// WordAttachDlg.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "WordAttach.h"
#include "WordAttachDlg.h"
#include "WordEventSink.h"
#include "WordCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



// CWordAttachDlg �_�C�A���O




CWordAttachDlg::CWordAttachDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWordAttachDlg::IDD, pParent)
	, mEvent(_T(""))
{
}

void CWordAttachDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EVENT, mEvent);
}

BEGIN_MESSAGE_MAP(CWordAttachDlg, CDialog)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_EVENTHOOK, &CWordAttachDlg::OnEventhook)
	ON_UPDATE_COMMAND_UI(ID_EVENTHOOK, &CWordAttachDlg::OnUpdateEventhook)
	ON_COMMAND(ID_EVENTUNHOOK, &CWordAttachDlg::OnEventunhook)
	ON_UPDATE_COMMAND_UI(ID_EVENTUNHOOK, &CWordAttachDlg::OnUpdateEventunhook)

	//	WORD�C�x���g
	ON_MESSAGE( WM_WORD_QUIT,		OnWordQuit )
	ON_MESSAGE( WM_WORD_DOCCHANGE,	OnWordDocChange )
	ON_MESSAGE( WM_WORD_DOCOPEN,	OnWordDocOpen )
	ON_MESSAGE( WM_WORD_DOCNEW,		OnWordDocNew )
	ON_MESSAGE( WM_WORD_WINACTIVATE,OnWordWinActivate )
	ON_MESSAGE( WM_WORD_SELCHANGE,	OnWordSelChange )

	ON_WM_DESTROY()
	ON_WM_INITMENUPOPUP()
	ON_COMMAND(ID_SCRZOOM, &CWordAttachDlg::OnScrzoom)
	ON_UPDATE_COMMAND_UI(ID_SCRZOOM, &CWordAttachDlg::OnUpdateScrzoom)
	ON_COMMAND(ID_SCRNORMAL, &CWordAttachDlg::OnScrnormal)
	ON_UPDATE_COMMAND_UI(ID_SCRNORMAL, &CWordAttachDlg::OnUpdateScrnormal)
END_MESSAGE_MAP()


// CWordAttachDlg ���b�Z�[�W �n���h��

//------------------------------------------------------------------------
//		WM_INITDIALOG
//------------------------------------------------------------------------
BOOL CWordAttachDlg::OnInitDialog()
{
	::CoInitialize(NULL);	//	COM������������

	CDialog::OnInitDialog();
	return TRUE;  // �t�H�[�J�X���R���g���[���ɐݒ肵���ꍇ�������ATRUE ��Ԃ��܂��B
}
//------------------------------------------------------------------------
//		WM_INITMENUPOPUP	�R�}���hUI�n���h����L���ɂ���
//------------------------------------------------------------------------
void CWordAttachDlg::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu)
{
	CDialog::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);

	CCmdUI cmdUI;
	cmdUI.m_pMenu=pPopupMenu;
	cmdUI.m_nIndexMax=pPopupMenu->GetMenuItemCount();
	for (cmdUI.m_nIndex=0;cmdUI.m_nIndex<pPopupMenu->GetMenuItemCount();cmdUI.m_nIndex++) {
		if (!(cmdUI.m_nID=pPopupMenu->GetMenuItemID(cmdUI.m_nIndex))) 
			continue;
		else if (cmdUI.m_nID==(UINT)-1) {
			cmdUI.m_pSubMenu=pPopupMenu->GetSubMenu(cmdUI.m_nIndex);
			if(!cmdUI.m_pSubMenu||!(cmdUI.m_nID=cmdUI.m_pSubMenu->GetMenuItemID(0))||(cmdUI.m_nID==(UINT)-1))
				continue;
			cmdUI.DoUpdate(this,FALSE);
		}
		else {
			cmdUI.m_pSubMenu=NULL;
			cmdUI.DoUpdate(this,cmdUI.m_nID<0xF000);
		}
	}
}
//------------------------------------------------------------------------
//		WM_DESTROY
//------------------------------------------------------------------------
void CWordAttachDlg::OnDestroy()
{
	OnEventunhook();	//	�t�b�N�̉���
	::CoUninitialize();	//	COM�̏I��

	CDialog::OnDestroy();
}
//------------------------------------------------------------------------
//		WORD�C�x���g�Ƀt�b�N
//------------------------------------------------------------------------
void CWordAttachDlg::OnEventhook()
{
	if(CWordEventSink::HookEvent( m_hWnd ) == false )
		::AfxMessageBox( TEXT("WORD�C�x���g�Ƀt�b�N�ł��܂���"),MB_OK | MB_ICONWARNING );
}
void CWordAttachDlg::OnUpdateEventhook(CCmdUI *pCmdUI)
{
	pCmdUI->Enable( CWordEventSink::IshookEvent()==false ? TRUE : FALSE );
}
//------------------------------------------------------------------------
//		WORD�C�x���g�t�b�N����
//------------------------------------------------------------------------
void CWordAttachDlg::OnEventunhook()
{
	CWordEventSink::UnhookEvent();
}
void CWordAttachDlg::OnUpdateEventunhook(CCmdUI *pCmdUI)
{
	pCmdUI->Enable( CWordEventSink::IshookEvent()==true ? TRUE : FALSE );
}


//***********************************************************************
//		WORD�C�x���g�n���h��
//
//------------------------------------------------------------------------
//		WORD�̏I��
//------------------------------------------------------------------------
LRESULT CWordAttachDlg::OnWordQuit( WPARAM wParam,LPARAM lParam )
{
	mEvent += TEXT("Quit\r\n");
	UpdateData( FALSE );
	((CEdit*)GetDlgItem( IDC_EVENT ))->SetSel( -1 );
	OnEventunhook();
	return	( NULL );
}
//------------------------------------------------------------------------
//		WORD�h�L�������g�̕ύX
//------------------------------------------------------------------------
LRESULT CWordAttachDlg::OnWordDocChange( WPARAM wParam,LPARAM lParam )
{
	mEvent += TEXT("DocChange - ");
	CStringW strDocName;
	if(CWordCtrl::GetDocumentName( strDocName )){
		mEvent += strDocName;
	}
	mEvent += TEXT("\r\n");
	UpdateData( FALSE );
	((CEdit*)GetDlgItem( IDC_EVENT ))->SetSel( -1 );
	return	( NULL );
}
//------------------------------------------------------------------------
//		WORD�h�L�������g�̃I�[�v��
//------------------------------------------------------------------------
LRESULT CWordAttachDlg::OnWordDocOpen( WPARAM wParam,LPARAM lParam )
{
	mEvent += TEXT("DocOpen\r\n");
	UpdateData( FALSE );
	((CEdit*)GetDlgItem( IDC_EVENT ))->SetSel( -1 );
	return	( NULL );
}
//------------------------------------------------------------------------
//		WORD�V�K�h�L�������g�̃I�[�v��
//------------------------------------------------------------------------
LRESULT CWordAttachDlg::OnWordDocNew( WPARAM wParam,LPARAM lParam )
{
	mEvent += TEXT("Document New\r\n");
	UpdateData( FALSE );
	((CEdit*)GetDlgItem( IDC_EVENT ))->SetSel( -1 );
	return	( NULL );
}
//------------------------------------------------------------------------
//		WORD �E�C���h�E�A�N�e�B�u
//------------------------------------------------------------------------
LRESULT CWordAttachDlg::OnWordWinActivate( WPARAM wParam,LPARAM lParam )
{
	mEvent += TEXT("WinActivate\r\n");
	UpdateData( FALSE );
	((CEdit*)GetDlgItem( IDC_EVENT ))->SetSel( -1 );
	return	( NULL );
}
//------------------------------------------------------------------------
//		WORD �I��ύX
//------------------------------------------------------------------------
LRESULT CWordAttachDlg::OnWordSelChange( WPARAM wParam,LPARAM lParam )
{
	mEvent += TEXT("SelChange - ");

	CString strSel;
	CWordCtrl::GetSelString( strSel );
	mEvent += strSel;
	mEvent += TEXT("\r\n");

	UpdateData( FALSE );
	((CEdit*)GetDlgItem( IDC_EVENT ))->SetSel( -1 );
	return	( NULL );
}
//------------------------------------------------------------------------
//		�g����
//------------------------------------------------------------------------
void CWordAttachDlg::OnScrzoom()
{
	CWordCtrl::SetScreenMode( WORD_SCREENMODE_MAGNIFICATION );
}

void CWordAttachDlg::OnUpdateScrzoom(CCmdUI *pCmdUI)
{
	if(CWordCtrl::GetScreenPercentage() == WORD_SCREENMODE_MAGNIFICATION )
		pCmdUI->SetCheck();
	else
		pCmdUI->SetCheck(0);
}
//------------------------------------------------------------------------
//		�ʏ���
//------------------------------------------------------------------------
void CWordAttachDlg::OnScrnormal()
{
	CWordCtrl::SetScreenMode( WORD_SCREENMODE_NORMAL );
}

void CWordAttachDlg::OnUpdateScrnormal(CCmdUI *pCmdUI)
{
	if(CWordCtrl::GetScreenPercentage() == WORD_SCREENMODE_NORMAL )
		pCmdUI->SetCheck();
	else
		pCmdUI->SetCheck(0);
}
